import { products } from "../../lib/products";

export default function handler(req, res) {
  // simple mock API: supports ?limit & ?skip
  const { limit = 12, skip = 0 } = req.query;
  const start = parseInt(skip, 10) || 0;
  const end = start + (parseInt(limit, 10) || 12);
  const slice = products.slice(start, end);
  res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=120");
  res.status(200).json({ total: products.length, data: slice });
}